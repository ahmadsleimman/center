<form role="form" method="POST" action="./index.php?page=savestudent">
    <div class="form-group">
        <label>Name</label>
        <input name="name" class="form-control" />
    </div>

    <div class="form-group">
        <label>Phone</label>
        <input name="phone" class="form-control" />
    </div>

    <div class="form-group">
        <label>Email</label>
        <input name="email" class="form-control" />
    </div>


    <div class="form-group">
        <label>Educactio level</label>
        <input name="educ_lvl" class="form-control" />
    </div>

    <div class="form-group">
        <label>age</label>
        <input name="age" class="form-control" />
    </div>


    <div class="form-group">
        <label>address</label>
        <!-- <input name="address" class="form-control" /> -->
        <textarea name="address"></textarea>
    </div>
    <div class="form-group">
        <button name="submit" type="submit" class="btn btn-primary form-control"> save</button>
    </div>
</form>