<?php
include_once("connection/connect.php");
if(isset($_POST["submit"])){


         


$name= $_POST["name"];
$email= $_POST["email"];
$phone= $_POST["phone"];
$educ_lvl= $_POST["educ_lvl"];
$age= $_POST["age"];
$address= $_POST["address"];


 

$insert_query="insert into students(fullname,phone, email, educ_lvl,age,adresse)
 values('".$name."',".$phone.",'".$email."','".$educ_lvl."',".$age.",'".$address."')";
 echo $insert_query;
 
 $result = mysqli_query($connexion, $insert_query);


 if($result){
    echo "data inserted successfully";
    header('location:index.php?page=students');

 }else{
    echo "wass";
    echo mysqli_error($connexion);
 }

// echo $insert_query;

}else{
echo "didn't enter the submit";

}




?>