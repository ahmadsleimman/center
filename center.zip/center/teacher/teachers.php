<?php
echo "i am in teacher";

?>